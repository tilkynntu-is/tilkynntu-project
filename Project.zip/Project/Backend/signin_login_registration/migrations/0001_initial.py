from home.models import Tag, Image, Report, Rating, Comment

class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Tag',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('text', models.CharField(max_length=64, unique=True)),
            ],
        ),
        migrations.CreateModel(
            name='Image',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('time_uploaded', models.DateTimeField(default=datetime.datetime.now, verbose_name='time uploaded')),
                ('url', models.URLField(max_length=1024)),
                ('alt_text', models.TextField()),
            ],
        ),
        migrations.CreateModel(
            name='Report',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('time_published', models.DateTimeField(default=datetime.datetime.now, verbose_name='time published')),
                ('loc_lat', models.DecimalField(decimal_places=6, max_digits=9)),
                ('loc_lng', models.DecimalField(decimal_places=6, max_digits=9)),
                ('title', models.CharField(max_length=64)),
                ('description', models.TextField()),
                ('image', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='signin_login_registration.image')),
                ('user_id', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
                ('tags', models.ManyToManyField(to='signin_login_registration.tag')),
            ],
        ),
        migrations.CreateModel(
            name='Rating',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('is_positive', models.BooleanField()),
                ('time_rated', models.DateTimeField(default=datetime.datetime.now, verbose_name='time rated')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.DO_NOTHING, to=settings.AUTH_USER_MODEL)),
                ('report', models.ForeignKey(on_delete=django.db.models.deletion.DO_NOTHING, to='signin_login_registration.report')),
            ],
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('time_posted', models.DateTimeField(default=datetime.datetime.now, verbose_name='time posted')),
                ('text', models.CharField(max_length=256)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.DO_NOTHING, to=settings.AUTH_USER_MODEL)),
                ('report', models.ForeignKey(null=True, on_delete=django.db.models.deletion.DO_NOTHING, to='signin_login_registration.report')),
            ],
        ),
    ]
