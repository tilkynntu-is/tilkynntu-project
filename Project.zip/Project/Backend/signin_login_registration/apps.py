from django.apps import AppConfig


class SigninLoginRegistrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'signin_login_registration'
